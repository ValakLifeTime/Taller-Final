import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Guerrero here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Terran extends Extraterrestre
{
    int energia = 100;
    /**
     * Act - do whatever the Guerrero wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Terran(String rol)
    {
     this.rol = rol;   
    }    
    public String getRol(){
     return rol;   
    }    
    public void act() 
    {
       maxEnergy();
       collectDeposit();
       moving();
       collectGasDeposit();
    }  
    public void collectDeposit(){
         World world;
         world = getWorld();
        MyWorld mundo = (MyWorld)world;
        EnergyCounter econt = mundo.getEcounter();
     if(isTouching(Deposito.class))
     {
     if(getRol() == "Terran")
     {   
        econt.addEnergy(20); 
        }   
        }
        removeTouching(Deposito.class);
    }  
    public void maxEnergy(){
     if(energia >=160){
     energia = 160;    
        }
    }
    public void collectGasDeposit()
    {
        World world;
        world = getWorld();
        MyWorld mundo = (MyWorld)world;
        Counter cont = mundo.getCounter();
       if(isTouching(GasDeposit.class))
     {
     if (getRol() == "Constructor")
     {    
        cont.addRecursos(40);
        }
        
        }
        removeTouching(GasDeposit.class);
    }
}
