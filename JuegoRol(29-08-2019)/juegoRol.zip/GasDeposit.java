import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GasDeposit here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GasDeposit extends Actor
{
    /**
     * Act - do whatever the GasDeposit wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public GasDeposit()
    {
     getImage().scale(getImage().getWidth()/2, getImage().getHeight()/2);    
    }    
    public void act() 
    {
        // Add your action code here.
    }   
        
}
