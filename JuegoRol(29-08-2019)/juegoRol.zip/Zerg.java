import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Medico here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Zerg extends Extraterrestre
{
    int energia = 120;
    /**
     * Act - do whatever the Medico wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Zerg(String rol)
    {
     this.rol = rol;  
     GreenfootImage image = getImage();  
     image.scale(30, 30);
     setImage(image);
    }
        
    public String getRol()
    {
     return rol;   
    } 
    public void act() 
    {
        maxEnergy();
        collectDeposit();
        moving();
        collectGasDeposit();
    }
  public void collectDeposit(){
         World world;
         world = getWorld();
        MyWorld mundo = (MyWorld)world;
        EnergyCounter econt = mundo.getEcounter();
     if(isTouching(Deposito.class))
     {
     if(getRol() == "Zerg")
     {   
        econt.addEnergy(15); 
        }   
        }
        removeTouching(Deposito.class);
    }  
    public void maxEnergy(){
     if(energia >=160){
     energia = 160;    
        }
    }
    public void collectGasDeposit()
    {
        World world;
        world = getWorld();
        MyWorld mundo = (MyWorld)world;
        Counter cont = mundo.getCounter();
       if(isTouching(GasDeposit.class))
     {
     if(getRol() == "Zerg")
     {        
        cont.addRecursos(45); 
     }    
     }
     removeTouching(GasDeposit.class);
    }
}
