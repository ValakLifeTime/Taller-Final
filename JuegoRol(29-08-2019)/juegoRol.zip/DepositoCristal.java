import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Deposito here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DepositoCristal extends Actor
{
    /**
     * Act - do whatever the Deposito wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public DepositoCristal(){
     getImage().scale(getImage().getWidth()/2, getImage().getHeight()/2);   
    }    
    public void act() 
    {
        // Add your action code here.
    }    
}
