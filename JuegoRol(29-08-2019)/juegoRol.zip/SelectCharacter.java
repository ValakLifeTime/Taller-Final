import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class SelectCharacter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SelectCharacter extends World
{
    int aux;
    PlayerChoice p1 = new PlayerChoice("Terran");
    PlayerChoice p2 = new PlayerChoice("Zerg");
    PlayerChoice p3 = new PlayerChoice("Protoss");
    /**
     * Constructor for objects of class SelectCharacter.
     * 
     */
    public SelectCharacter()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1200, 800, 1); 
        addObject(p1, 272, 384);
        addObject(p2, 587, 384);
        addObject(p3, 880, 384);
        
    }
    public void act()
    {
     changeWorld();   
    }
    public void changeWorld()
    {
     if(Greenfoot.mouseClicked(p1))
      {
          Greenfoot. setWorld(new MyWorld("Terran",azar()));
          aux=0;
        } 
      else  if(Greenfoot.mouseClicked(p2))
      {
          Greenfoot. setWorld(new MyWorld("Zerg", azar()));
          aux=1;
        } 
       else if(Greenfoot.mouseClicked(p3))
      {
          Greenfoot. setWorld(new MyWorld("Protoss", azar()));
          aux=2;
        } 
        
    } 
    public String azar()
    {
     int a;
     String raza="";
     a = Greenfoot.getRandomNumber(2);
     if(aux==0)
     {
     switch(a)
     {
     
     case 0: raza = "Zerg"; break;
     case 1: raza = "Protoss"; break;
     }     
    }  
    else if(aux==1)
     {
     switch(a) 
     {   
     case 0: raza = "Terran"; break;
     case 1: raza = "Protoss"; break;
     }     
    } 
    else if(aux==2)
     {
     switch(a)
     {
     
     case 0: raza = "Zerg"; break;
     case 1: raza = "Terran"; break;
     }     
    } 
    return raza;
}
}
