import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Constructor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Protoss extends Extraterrestre
{
    int energia = 100;
    String rol;
    /**
     * Act - do whatever the Constructor wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Protoss(String rol){
     this.rol = rol; 
     GreenfootImage image = getImage();  
     image.scale(50, 50);
     setImage(image);
    }    
    public String getRol(){
     return rol;   
    } 
    public void act() 
    {
        maxEnergy();
        corner();
        collectDeposit();
        collectGasDeposit();
        moving();
    }  
    public void collectDeposit(){
         World world;
         world = getWorld();
        MyWorld mundo = (MyWorld)world;
        EnergyCounter econt = mundo.getEcounter();
     if(isTouching(Deposito.class))
     {
     if(getRol() == "Constructor")
     {   
        econt.addEnergy(25); 
        }   
        }
        removeTouching(Deposito.class);
    } 
    public void collectGasDeposit()
    {
        World world;
        world = getWorld();
        MyWorld mundo = (MyWorld)world;
        Counter cont = mundo.getCounter();
       if(isTouching(GasDeposit.class))
     {
     if(getRol() == "Constructor")
     {   
       cont.addRecursos(35);
     }
     }
     
    }    
    public void maxEnergy(){
     if(energia >=160){
     energia = 160;    
        }
    }
}
