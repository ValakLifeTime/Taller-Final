import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player extends Actor
{
    public boolean estado=true;
    public String raza;
    /**
     * Act - do whatever the Player wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
    public boolean turno()
    {
     if(estado){
     return false;
        }
     else{
         return true;
        }    
    }
    public void setRaza(String a)
    {
        this.raza = a;
    } 
    public String getRaza()
    {
     return this.raza;  
    }    
}
