import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Energia here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Energia extends Actor
{
    int energy = 100;
    int speed = 4;
    /**
     * Act - do whatever the Energia wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
      
    public Energia()
    {
        setImage(new GreenfootImage("Energia: "+energy, 15, Color.BLACK, null));
    }
    public void act() 
    {
       setImage(new GreenfootImage("Energia: "+energy, 15, Color.BLACK, null));
       moving();
    }    
    public void moving()
    {
     if(Greenfoot.isKeyDown("up"))  
     {
        
         setLocation(getX(), getY() - speed);   
        
     }
     if(Greenfoot.isKeyDown("down"))  
     {
         
         setLocation(getX(), getY() + speed);   
        
         
     }
     if(Greenfoot.isKeyDown("right"))  
     {
         setLocation(getX() + speed, getY());
         
     }
     if(Greenfoot.isKeyDown("left"))  
     {
         setLocation(getX() - speed, getY());
         
     }
    }
}
