import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (Jose Silva) 
 * @version (1.0 14/07/2019)
 */
public class MyWorld extends World
{
    int cantI = 5;
    String p1Raza,p2Raza;
    Counter cont = new Counter();
    EnergyCounter econt = new EnergyCounter();
    int x=Greenfoot.getRandomNumber(1200), y = Greenfoot.getRandomNumber(800);
    Player player1 = new Player();
    Player player2 = new Player();
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
       
    public MyWorld(String p1, String p2)
    {    
        
        super(1200, 800, 1); 
        this.p1Raza = p1;
        this.p2Raza = p2;
        addObject(new Deposito(), Greenfoot.getRandomNumber(1200),Greenfoot.getRandomNumber(800));
        addObject(new Deposito(), Greenfoot.getRandomNumber(1200),Greenfoot.getRandomNumber(800));
        addObject(new Deposito(), Greenfoot.getRandomNumber(1200),Greenfoot.getRandomNumber(800));
        addObject(new GasDeposit(), Greenfoot.getRandomNumber(1200),Greenfoot.getRandomNumber(800));
        addObject(new GasDeposit(), Greenfoot.getRandomNumber(1200),Greenfoot.getRandomNumber(800));
        crear();
        prepare();
       
    }
        
    public Counter getCounter()
    {
     return cont;   
    } 
    public EnergyCounter getEcounter()
    {
     return econt;   
    }    
    public void prepare()
    {  
 
     addObject(cont, 1050,50);  
     
    }    
    public void generarExtraterrestres(String a, int num,int alcanze)
    {
        if(a == "Protoss")
        {
        for(int i=0; i<num; i++)
        {
         Protoss p = new Protoss(generarParametro());
         int x = Greenfoot.getRandomNumber(alcanze);
         int y = Greenfoot.getRandomNumber(getHeight());
         addObject(p,x,y);
         addObject(new EnergyCounter(), x,y-20);
        } 
    }
        else if(a == "Terran")
        {
        for(int i=0; i<num; i++)
        {
         Terran t = new Terran(generarParametro());
         int x = Greenfoot.getRandomNumber(alcanze);
         int y = Greenfoot.getRandomNumber(getHeight());
         addObject(t,x,y);
         addObject(new EnergyCounter(), x,y-20);
        } 
    }
        else if(a == "Zerg")
        {
        for(int i=0; i<num; i++)
        {
         Zerg z = new Zerg(generarParametro());
         int x = Greenfoot.getRandomNumber(alcanze);
         int y = Greenfoot.getRandomNumber(getHeight());
         addObject(z,x,y);
         addObject(new EnergyCounter(), x,y-20);
        }
    }
    }    
    public void crear()
    {    
    generarExtraterrestres(p1Raza,5,getWidth()/2);
    generarExtraterrestres(p2Raza,5,getRandomNumber(getWidth()/2,getWidth()));
    }  
    public String generarParametro()
    {
     int opc = Greenfoot.getRandomNumber(2);
     String aux;
     switch(opc)
     {
     case 0: aux = "Guerrero";
     break;
     case 1: aux = "Constructor";
     break;
     case 2: aux="Medico";
     break;
     default: aux = "Guerrero"; break;
    }
    return aux;
}
public int getRandomNumber(int start,int end)
{
       int normal = Greenfoot.getRandomNumber(end-start+1);
       return normal+start;
}
}    

