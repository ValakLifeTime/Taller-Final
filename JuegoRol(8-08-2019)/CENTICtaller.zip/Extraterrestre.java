import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Extraterrestre here.
 * 
 * @author (Jose Silva) 
 * @version (1.0  14/07/2019)
 */
public class Extraterrestre extends Actor
{
    int speed = 1;
    public int energia;
    public String rol;
    public EnergyCounter contEnergia;
    public Counter contRecursos;
    public Player player;
    long lastAdded = System.currentTimeMillis();
    /**
     * 
     */
    public Extraterrestre()
    {
        getImage().scale(getImage().getWidth()/2, getImage().getHeight()/2);
        
    }    
     public String getRol(){
     return rol;   
    } 
    /**
     * Act - do whatever the Extraterrestre wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        //esto de momento es un inicio para hacerlo por turnos (no fijarse 3/08/2019)
        World world;
         world = getWorld();
        Koprulu mundo = (Koprulu)world;
        Player player1 = mundo.player1;
        //no fijarse xd
        if(player1.turno()){
        moving();
        corner();
    }
    else{
        
    }    
    
    }

    /**
     * metodo para moverse con las teclas.
     */
    public void moving()
    {
        int random = Greenfoot.getRandomNumber(9);
        //Greenfoot.delay(1);
        int auxI=5;
        
        switch (random)
            {
                case 1:for (int i=0; i<auxI;i++){
                    setLocation(getX()+speed, getY());
                }break;
        
                case 2:for (int i=0; i<auxI;i++){
                    setLocation(getX()-speed, getY());
                }break;
                case 3:for (int i=0; i<auxI;i++){
                    setLocation(getX()+speed, getY()+speed);
                }break;
                case 4:for (int i=0; i<auxI;i++){
                    setLocation(getX()+speed, getY()-speed);
                }break;
                case 5:for (int i=0; i<auxI;i++){
                    setLocation(getX(), getY()+speed);
                }break;
                case 6:for (int i=0; i<auxI; i++){
                    setLocation(getX(), getY()-speed);
                }
                case 7:for (int i=0; i<auxI; i++){
                    setLocation(getX()-speed, getY()-speed);
                }
                case 8:for (int i=0 ; i<auxI; i++){
                    setLocation(getX()+speed, getY());
                  
                }
                
            }
    
    }  
      
    
    /**
     *  Metodo para identificar si se encuentra al limite del mundo
     */
    public void corner()
    {
       isAtEdge();
    }
    
    public boolean choqueObstaculo()
    {
        if(isTouching(Obstaculo.class)){
            return true;
        }
        else
        {
            return false;
        }
    }
        
       
}
